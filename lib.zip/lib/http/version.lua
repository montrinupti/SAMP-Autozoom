--[[
This file contains the lua-http release.
It should be updated as part of the release process
]]

return {
	name = "lua-http";
	version = "scm";
}
